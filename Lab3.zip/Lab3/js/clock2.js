let canvas = document.getElementById("clockCanvas");
let context = canvas.getContext("2d");
let clockRadius = 95;
let clockOriginX = canvas.width / 2;
let clockOriginY = canvas.height / 2;
let hourMarkLength = 20;
let minuteMarkLength = hourMarkLength / 2;

// Event listeners
document.getElementById("currentTimeBtn").addEventListener("click", currentTime);
document.getElementById("hourInput").addEventListener("input", drawUserTime);
document.getElementById("minuteInput").addEventListener("input", drawUserTime);
document.getElementById("secondInput").addEventListener("input", drawUserTime);

// Initialize clock
currentTime();

function drawClock() {
    context.clearRect(0, 0, canvas.width, canvas.height);
    context.beginPath();
    context.arc(clockOriginX, clockOriginY, clockRadius, 0, 2 * Math.PI);
    context.stroke();

    // Draw center dot
    context.beginPath();
    context.arc(clockOriginX, clockOriginY, 2, 0, 2 * Math.PI);
    context.fill();
    context.stroke();

    // Draw hour and minute markers
    for (let i = 0; i < 60; i++) {
        context.save();
        context.translate(clockOriginX, clockOriginY);
        let calculateRotate = (Math.PI / 180) * (360 / 60) * i;
        context.rotate(calculateRotate);
        context.translate(-clockOriginX, -clockOriginY);
        context.beginPath();
        context.moveTo(clockOriginX, clockOriginY - clockRadius);

        let markLength = i % 5 === 0 ? clockOriginY - clockRadius + hourMarkLength : clockOriginY - clockRadius + minuteMarkLength;
        context.lineWidth = i % 5 === 0 ? 2 : 1;

        context.lineTo(clockOriginX, markLength);
        context.stroke();
        context.restore();
    }
}

function drawHourHand(hour) {
    context.save();
    context.translate(clockOriginX, clockOriginY);
    let calculateRotate = (Math.PI / 180) * (360 / 12) * (hour % 12);
    context.rotate(calculateRotate);
    context.translate(-clockOriginX, -clockOriginY);
    
    context.beginPath();
    context.strokeStyle = "blue";
    context.fillStyle = "blue";
    context.lineWidth = 5;
    context.moveTo(clockOriginX, clockOriginY);
    context.lineTo(clockOriginX, clockOriginY - clockRadius / 2);
    context.stroke();

    context.restore();
}

function drawMinuteHand(minute) {
    context.save();
    context.translate(clockOriginX, clockOriginY);
    let calculateRotate = (Math.PI / 180) * (360 / 60) * (minute % 60);
    context.rotate(calculateRotate);
    context.translate(-clockOriginX, -clockOriginY);

    context.beginPath();
    context.strokeStyle = "black";
    context.lineWidth = 4;
    context.moveTo(clockOriginX, clockOriginY);
    context.lineTo(clockOriginX, clockOriginY - (clockRadius - 15));
    context.stroke();

    context.restore();
}

function drawSecondHand(second) {
    context.save();
    context.translate(clockOriginX, clockOriginY);

    let calculateRotate = (Math.PI / 180) * (360 / 60) * (second % 60);
    context.rotate(calculateRotate);
    context.translate(-clockOriginX, -clockOriginY);

    context.beginPath();
    context.strokeStyle = "red";
    context.lineWidth = 2;
    context.moveTo(clockOriginX, clockOriginY);
    context.lineTo(clockOriginX, clockOriginY - (clockRadius - 10));
    context.stroke();

    context.restore();
}

function currentTime() {
    let today = new Date();
    let hour = today.getHours() % 12 || 12;
    document.getElementById("hourInput").value = formatTime(hour);
    document.getElementById("minuteInput").value = formatTime(today.getMinutes());
    document.getElementById("secondInput").value = formatTime(today.getSeconds());
    drawUserTime();
}

function drawUserTime() {
    let hour = Number(document.getElementById("hourInput").value);
    let minutes = Number(document.getElementById("minuteInput").value);
    let seconds = Number(document.getElementById("secondInput").value);
    drawTime(hour, minutes, seconds);
}

function drawTime(hour, minutes, seconds) {
    let minuteOffset = seconds / 60;
    let hourOffset = (minutes + minuteOffset) / 60;
    
    drawClock();
    drawHourHand(hour + hourOffset);
    drawMinuteHand(minutes + minuteOffset);
    drawSecondHand(seconds);
}

// Helper function to format time with leading zeroes
function formatTime(time) {
    return time < 10 ? `0${time}` : time;
}
