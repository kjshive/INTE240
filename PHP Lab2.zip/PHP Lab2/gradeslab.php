<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>IT Grades</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f0f2f5;
      margin: 0;
      padding: 0;
    }
    .container {
      max-width: 600px;
      margin: 60px auto;
      background-color: #fff;
      padding: 30px 40px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.1);
      border-radius: 10px;
    }
    h1 {
      text-align: center;
      color: #333;
      margin-bottom: 25px;
    }
    .message {
      font-size: 16px;
      margin-bottom: 10px;
    }
    .success {
      color: green;
      font-weight: bold;
    }
    .error {
      color: red;
      font-weight: bold;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>IT Grades Setup</h1>
    <div>
      <?php
      $servername = "localhost";
      $username = "root";
      $password = "";
      $dbname = "";

      $conn = new mysqli($servername, $username, $password, $dbname);

      if ($conn->connect_error) {
        die("<p class='message error'>Connection failed: " . $conn->connect_error . "</p>");
      }

      $sql = "DROP DATABASE IF EXISTS itgrades;";
      if ($conn->query($sql) === TRUE) {
        echo "<p class='message success'>Step 1: Database deleted successfully</p>";
      } else {
        echo "<p class='message error'>Error: " . $sql . "<br>" . $conn->error . "</p>";
      }

      $sql = "CREATE DATABASE itgrades;";
      if ($conn->query($sql) === TRUE) {
        echo "<p class='message success'>Step 2: Database 'itgrades' created successfully</p>";
      } else {
        echo "<p class='message error'>Error: " . $sql . "<br>" . $conn->error . "</p>";
      }

      $sql = "CREATE TABLE `itgrades`.`inte` (
        `id` INT NOT NULL AUTO_INCREMENT,
        `course` VARCHAR(25) NOT NULL,
        `grade` VARCHAR(3) NOT NULL,
        PRIMARY KEY (`id`)
      ) ENGINE = InnoDB;";
      if ($conn->query($sql) === TRUE) {
        echo "<p class='message success'>Step 3: Table 'inte' created successfully</p>";
      } else {
        echo "<p class='message error'>Error: " . $sql . "<br>" . $conn->error . "</p>";
      }

      $conn->close();
      ?>
    </div>
  </div>
</body>
</html>
