<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Insert Grade</title>
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background-color: #eef2f5;
      margin: 0;
      padding: 0;
    }
    .container {
      max-width: 600px;
      margin: 80px auto;
      background-color: #ffffff;
      padding: 30px 40px;
      border-radius: 12px;
      box-shadow: 0 6px 15px rgba(0, 0, 0, 0.1);
    }
    h1 {
      text-align: center;
      color: #333;
      margin-bottom: 30px;
    }
    .message {
      font-size: 18px;
      padding: 15px;
      border-radius: 8px;
      text-align: center;
      margin-top: 20px;
    }
    .success {
      background-color: #d4edda;
      color: #155724;
      border: 1px solid #c3e6cb;
    }
    .error {
      background-color: #f8d7da;
      color: #721c24;
      border: 1px solid #f5c6cb;
    }
    .details {
      font-size: 16px;
      color: #555;
      text-align: center;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>Insert Grade</h1>
    <?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "itgrades";

    $course = "INTE 240";
    $grade = "A";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
      die("<div class='message error'>Connection failed: " . $conn->connect_error . "</div>");
    }

    $sql = "INSERT INTO inte (course, grade) VALUES ('$course', '$grade')";

    if ($conn->query($sql) === TRUE) {
      echo "<div class='message success'>New record created successfully</div>";
      echo "<div class='details'>Course: <strong>$course</strong> | Grade: <strong>$grade</strong></div>";
    } else {
      echo "<div class='message error'>Error: " . $sql . "<br>" . $conn->error . "</div>";
    }

    $conn->close();
    ?>
  </div>
</body>
</html>
