<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Grades for Courses</title>
  <style>
    body {
      background: linear-gradient(to right, #ffecd2, #fcb69f);
      font-family: 'Comic Sans MS', cursive, sans-serif;
      padding: 40px;
      color: #333;
    }

    h2 {
      font-size: 32px;
      color: #d84315;
      text-align: center;
      margin-bottom: 30px;
      text-shadow: 1px 1px #fff;
    }

    .grade-line {
      font-size: 22px;
      margin: 10px auto;
      padding: 10px 20px;
      max-width: 500px;
      background-color: #fff3e0;
      border-left: 8px solid #ff6f00;
      border-radius: 10px;
      box-shadow: 2px 2px 8px rgba(0,0,0,0.1);
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .emoji {
      margin-right: 10px;
    }

    .no-data {
      text-align: center;
      background-color: #fff9c4;
      color: #f57f17;
      padding: 15px;
      border-radius: 12px;
      font-size: 20px;
      margin-top: 20px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.1);
    }
  </style>
</head>
<body>
  <h2>📚 Here are your current IT grades!</h2>
  <?php
  $servername = "localhost";
  $username = "root";
  $password = "";
  $dbname = "itgrades";

  $conn = new mysqli($servername, $username, $password, $dbname);

  if ($conn->connect_error) {
    die("<div class='no-data'>⚠️ Connection failed: " . $conn->connect_error . "</div>");
  }

  $sql = "SELECT course, grade FROM inte;";
  $result = $conn->query($sql);

  if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
      echo "<div class='grade-line'>
              <span class='emoji'>📘</span>
              <span>{$row["course"]} — <strong>{$row["grade"]}</strong></span>
              <span class='emoji'>✅</span>
            </div>";
    }
  } else {
    echo "<div class='no-data'>😢 There are no grades currently in the system</div>";
  }

  $conn->close();
  ?>
</body>
</html>
