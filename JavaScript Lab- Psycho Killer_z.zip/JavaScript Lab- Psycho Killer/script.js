const lyrics = [
    { time: 0, text: "Introduction - David Byrne" },
    { time: 33, text: "I can't seem to face up to the facts" },
    { time: 38, text: "I'm tense and nervous and I can't relax" },
    { time: 42, text: "I can't sleep because my bed's on fire" },
    { time: 46, text: "Don't touch me I'm a real live wire" },
    { time: 51, text: "Psycho Killer, qu'est-ce que c'est?" },
    { time: 55, text: "Fa fa fa fa fa fa fa fa fa fa fa fa fa fa fa fa fa..." },
    { time: 60, text: "Run, run, run, run, run, run, run away, oh-oh-oh" },
    { time: 67, text: "Ay-ya-ya-ya-ya-ya, ooh" },
    { time: 80, text: "You start a conversation, you can't even finish it" },
    { time: 84, text: "You're talking a lot, but you're not saying anything" },
    { time: 88, text: "When I have nothing to say, my lips are sealed" },
    { time: 92, text: "Say something once, why say it again?" },
    { time: 97, text: "Psycho Killer" },
    { time: 99, text: "Qu'est-ce que c'est?" },
    { time: 101, text: "Fa-fa-fa-fa, fa-fa-fa-fa-fa-fa, better" },
    { time: 105, text: "Run, run, run, run, run, run, run away, oh-oh-oh" },
    { time: 114, text: "Psycho Killer" },
    { time: 116, text: "Qu'est-ce que c'est?" },
    { time: 118, text: "Fa-fa-fa-fa, fa-fa-fa-fa-fa-fa, better" },
     {time: 123, text: "Run, run, run, run, run, run, run away, oh, oh, oh, oh" },
    { time: 130, text: "Ay-ya-ya-ya-ya-ya" },
    { time: 134, text: "Ce que j'ai fait, ce soir-là" },
    { time: 143, text: "Ce qu'elle a dit, ce soir-là" },
    { time: 151, text: "Réalisant mon espoir" },
    { time: 156, text: "Je me lance vers la gloire, okay" },
    { time: 164, text: "Yeah, yeah, yeah, yeah, yeah, yeah, yeah, yeah, yeah, yeah" },
    { time: 168, text: "We are vain and we are blind" },
    { time: 172, text: "I hate people when they're not polite" },
    { time: 177, text: "Psycho Killer" },
    { time: 179, text: "Qu'est-ce que c'est?" },
    { time: 181, text: "Fa-fa-fa-fa, fa-fa-fa-fa-fa-fa, better" },
    { time: 185, text: "Run, run, run, run, run, run, run away, oh-oh-oh" },
    { time: 193, text: "Ai-ya-ya-ya-ya-ya, ooh" },
    { time: 200, text: "Instrumental end" },
    ];

let currentLyricIndex = 0;
const audio = document.getElementById("audio");
const lyricElement = document.getElementById("lyric");
audio.addEventListener("play", () => {
setInterval(displayLyrics, 100);
accuracy
});
function displayLyrics() {
    const currentTime = audio.currentTime;
    if (
    currentLyricIndex < lyrics.length &&
    currentTime >= lyrics[currentLyricIndex].time
    ) {
    lyricElement.textContent = lyrics[currentLyricIndex].text;
    currentLyricIndex++;
    }
    }